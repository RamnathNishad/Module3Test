import { Component } from '@angular/core';
import allproducts from './models/products'; //all the products imported here

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'products-shopping';
  products=allproducts;  //array of products
}
