let products = [{
  id: 1,
  name: "Samsung Galaxy Note 10",
  imageUrl: "/assets/images/samsung_galaxy.jpg",
  category: "Mobile Phones",
  price: 69900,
  stock: 5
},
{
  id: 2,
  name: "IBall Slide Spirit X2",
  imageUrl: "/assets/images/ibal_slide_spirit.jpg",
  category: "Mobile Phones",
  price: 4999,
  stock: 0
},
{
  id: 3,
  name: "Infinix Smart 3 plus",
  imageUrl: "/assets/images/infinix_smart_plus.jpg",
  category: "Mobile Phones",
  price: 2999,
  stock: 25
},
{
  id: 4,
  name: "SkullCandy BT Inkd Plus",
  imageUrl: "/assets/images/skull_candy.jpg",
  category: "Headset",
  price: 1999,
  stock: 20
},
{
  id: 5,
  name: "Anker Soundbuds Rise",
  imageUrl: "/assets/images/anker_soundbudds.jpg",
  category: "Headset",
  price: 2999,
  stock: 0
},
{
  id: 6,
  name: "Skullcandy Set 2.0 Rise",
  imageUrl: "/assets/images/skullcandy_set2.jpg",
  category: "Headset",
  price: 2999,
  stock: 25
},
{
  id: 7,
  name: "Apple Watch Series",
  imageUrl: "/assets/images/apple_watch.jpg",
  category: "Watch",
  price: 52940,
  stock: 2
},
{
  id: 8,
  name: "Timex Three Hand",
  imageUrl: "/assets/images/timex_three_hand.jpg",
  category: "Watch",
  price: 2999,
  stock: 25
},
{
  id: 9,
  name: "JBL Fli 3 Bluetooth speaker",
  imageUrl: "/assets/images/jbl_flip3_speaker.jpg",
  category: "Speakers",
  price: 5999,
  stock: 7
},
{
  id: 10,
  name: "Sony XB01 EXTRA BASS",
  imageUrl: "/assets/images/sony_extra_bass.jpg",
  category: "Speakers",
  price: 8777,
  stock: 0
}];

export default products;