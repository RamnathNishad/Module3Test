import logo from './logo.svg';
import './App.css';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';

import mobiles from './models/mobiles'; //all mobiles are imported here


function App() {
  return (
    <div className="App">
      <h1 className='alert alert-info'>Welcome to React</h1>
    </div>
  );
}

export default App;
