let mobiles = [{
    id: 1,
    name: "One Plus 7 Pro",
    imageUrl: "/images/one_plus_7_pro.jpg",
    rating:4.0,
    configuration:"8 GB RAM|256 GB ROM",
    display:"16.94 cm (6.67 inch) Display",
    description:`13.84 cm(5.45 inch) HD+ Display,
    12MP Rear Camera | 5MP Front Camera, 
    4000 mAh, Li-Polymer Battery. 
    Qualcomm Snapdragon 439 Processor 
    Brand Warranty of 2 Years Available 
    for mobile and 6 Months for Accessories`, 
    stock: 30, 
    price: 48999    
  },
  {
    id: 2,
    name: "iPhone XR",
    imageUrl: "/images/iphone_xr.jpg",
    rating:3.5,
    configuration:"128 GB ROM",
    display:"15.49 cm (6.1 inch) Display",
    description:`12MP Rear Camera | 7MP Front Camera, 
    A12 Bonic Chip Processor, Brand Warranty of 1 Year`, 
    stock: 10, 
    price: 64999   
  },
  {
    id: 3,
    name: "Tizen",
    imageUrl: "/images/tizen.jpg",
    rating:4.5,
    configuration:"1 GB RAM|8 GB ROM|Expandable upto 128 GB",
    display:"12.7 cm (5 inch) HD Display",
    description:`8MP Rear Camera | 5MP Front Camera, 
    2600 mAh, Li-Ion Battery. 
    1 Year Manufacturer Warranty`, 
    stock: 5, 
    price: 4999    
  },
  {
    id: 4,
    name: "One Plus 1",
    imageUrl: "/images/one_plus_1.jpg",
    rating:3.5,
    configuration:"3 GB RAM|32 GB ROM",
    display:"14.48 cm (5.7 inch) HD+ Display",
    description:`12MP Rear Camera | 5MP Front Camera, 
    4000 mAh, Li-Polymer Battery. 
    Qualcomm Snapdragon 439 Processor,
    Brand Warranty of 2 Years,
     and 6 Months for Accessories`, 
    stock: 0, 
    price: 25999    
  }
]

export default mobiles;